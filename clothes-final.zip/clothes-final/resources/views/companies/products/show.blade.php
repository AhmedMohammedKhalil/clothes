@extends('companies.layout')
@section('section')
    @include('common.product',['page'=>'company'])
@endsection
