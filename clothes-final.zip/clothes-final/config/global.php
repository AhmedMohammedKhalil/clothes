<?php

return [
    'page_type' => '',
    'content' => ''
];
